import { config } from 'dotenv';
config();

import '@/ai/flows/generate-legal-document.ts';
import '@/ai/flows/improve-legal-document.ts';